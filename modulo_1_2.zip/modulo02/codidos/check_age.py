def CheckAge(age):
  age = int(age);

  if age >= 18:
    print("maior de idade");
    verify = "OK";
  else:
    print("menor de idade") ;
    verify = "ERRO";
  
  return verify;

age = input("Didgite a idade: ")
result = CheckAge(age);
print("Resultado da verificação:", str(result));
