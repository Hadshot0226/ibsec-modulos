import sys;

if len(sys.argv) > 2:
  print("Passou todos os argumentos");
else:
  print("Faltou argumentos. \nExemplo: python3 valor1 valor2");
  exit(0);
name_program = sys.argv[0];
argument_01 = sys.argv[1];
argument_02= sys.argv[2];

print("\nNome do programa: ",  name_program);
print("Argumento 01: ",  argument_01);
print("Argumento 02: ",  argument_02);