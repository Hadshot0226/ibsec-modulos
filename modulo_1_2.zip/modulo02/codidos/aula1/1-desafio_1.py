import sys

# funcao para calculo de pagamento
def calculo_pagamento(qtd_horas, valor_hora):
    qtd_horas = float(qtd_horas)
    valor_hora = float(valor_hora)

    # verifica se teve horas extras
    if qtd_horas <= 40:
        print("nao teve horas extras")
        salario = qtd_horas * valor_hora
    else:
        print("excedeu a jornada de 40 horas")
        # calcula quantidade de horas extras
        horas_extras = qtd_horas - 40
        print("total de horas extras", horas_extras)
        # incrementa valor bonus adicional em cima da hora extra
        valor_extra = horas_extras * (1.5 * valor_hora)
        # soma valor hora + valor hora extra
        salario = 40 * valor_hora + valor_extra

    return salario

# valida se o usuario passou os 2 parametros necessarios
if len(sys.argv) > 2:
    print("passou todos argumentos")
else:
    print("argumentos faltantes, informe a qtd de horas e valor hora")
    exit(0)

# formata para decimal
qtd_horas = float(sys.argv[1])
valor_hora = float(sys.argv[2])

# chama funcao de calculo de pagamento 
pagamento = calculo_pagamento(qtd_horas,valor_hora)
print("Valor de pagamento da semana: " + str(pagamento))