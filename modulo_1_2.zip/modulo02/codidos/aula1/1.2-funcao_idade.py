
def verifica_idade(idade):
    idade = int(idade)
    if idade >= 18:
        print("maior de idade")
        verificacao = "OK"
    else:
        print("menor de idade")
        verificacao = "ERRO"

    return verificacao

idade = input('Digite sua idade: ')
valida_idade = verifica_idade(idade)
print("Resultado da validacao: " + valida_idade)




