import sys

"""
if len(sys.argv) > 2:
    print("passou todos argumentos")
else:
    print("argumentos faltantes")
    exit(0)
"""

nome_programa = sys.argv[0]
argumento_1 = sys.argv[1]
argumento_2 = sys.argv[2]


print("Programa: " + nome_programa)
print("Argumento 1: " + argumento_1)
print("Argumento 2: " + argumento_2)


