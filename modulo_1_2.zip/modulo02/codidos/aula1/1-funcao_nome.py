def escreve_nome(nome):
    print(nome)

nome = input('Digite o seu nome: ')
escreve_nome(nome)

