# count
print("count")
frase = "Hoje estou feliz, em minha casa"
contagem = frase.count('o')
print(contagem)
print("\n")

# find
print("find")
frase = "Hoje estou feliz, em minha casa"
posicao = frase.find('feliz')
print("Posicao " + str(posicao))
print("\n")

# join
print("join")
texto = ('Hoje', 'estou', 'feliz')
espaco = ' '
saida = espaco.join(texto)
print(saida)
print("\n")

# strip()
print("strip")
texto = "  Python  "
saida = texto.strip()
print("Linguagem",texto)
print("Linguagem",saida)
print("\n")


texto = ",  Python  xpto"
saida = texto.strip(',xpto ')
print("Linguagem",texto)
print("Linguagem",saida)
print("\n")


# replace
print("replace")
texto = "Hoje, estou, muito, feliz"
saida = texto.replace(',' , '')
print(saida)
print("\n")


# split
print("split")
texto = "Hoje, estou, muito, feliz"
texto = texto.replace(', ' , ',')
palavras = texto.split(',')
print(texto)

for i in palavras:
    print(i)

print("\n")
