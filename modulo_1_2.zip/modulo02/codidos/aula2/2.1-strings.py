# upper
print("upper")
texto = 'teste'
print(texto.upper())
print("\n")

# lower
print("lower")
texto = 'TESTE'
print(texto.lower())
print("\n")

# len
print("len")
texto = 'abcde'
print(len(texto))
print("\n")

# startswith
print("startswith")
texto = 'ola mundo'
print(texto.startswith('xpto'))
print(texto.startswith('ola'))
print("\n")

# endswith
print("endswith")
texto = 'ola mundo'
print(texto.endswith('xpto'))
print(texto.endswith('ola'))
print(texto.endswith('mundo'))
print("\n")

# isdigit
print("isdigit")
texto = 'abc1'
print(texto.isdigit())
texto = '123'
print(texto.isdigit())
print("\n")


# isalpha
print("isalpha")
texto = 'abc'
print(texto.isalpha())
texto = '123abc'
print(texto.isalpha())
print("\n")

# isalnum
print("isalnum")
texto = '123'
print(texto.isalnum())
texto = '123abc'
print(texto.isalnum())
print("\n")