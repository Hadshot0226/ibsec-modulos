# coding: utf-8
print("coding: utf-8")
nome = 'João Silva'
print(nome)
print("\n")

# type
print("type")
nome = 'Ricardo'
print(type(nome))
print("\n")

# indice
print("indice")
nome = 'Ricardo'
print(nome[0])

nome = 'Ricardo'
print(nome[0:5])

nome = 'Ricardo'
print(nome[-1])
print("\n")