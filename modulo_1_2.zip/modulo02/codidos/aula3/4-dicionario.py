# funcao get
print("//funções get")
pessoa = {'nome': 'Bruno', 'altura': 1.65, 'idade': 21}

print(pessoa['nome'])

print(pessoa.get('nome'))
print("\n")

# atributo inexistente
print("//atributo inexistente")
print(pessoa.get('peso'))
print(pessoa.get('peso', 'Chave nao encontrada'))
print("\n")

# keys / chaves
print("//keys / chaves")
computador = {'CPU': 'Intel', 'RAM': '8GB', 'HD': '250GB'}
print(computador.keys())
print("\n")

# values / valores
print("//values / valores")
computador = {'CPU': 'Intel', 'RAM': '8GB', 'HD': '250GB'}
print(computador.values())
print("\n")

# percorrendo chaves e valores
print("//percorrendo chaves e valores")
computador = {'CPU': 'Intel', 'RAM': '8gb', 'SSD': '250bg'}
for chave in computador.keys():
  print(f'Chave = {chave}')
print("\n")

# percorrendo valores
print("//percorrendo valores")
notas = {'Mat': 5, 'Por': 7, 'His': 8}

for valor in notas.values():
    print(f'Valor: {valor}')
print("\n")

# percorrendo valores exemplo 2
print("//percorrendo valores exemplo 2")
frutas = {'pera': 10, 'uva': 2, 'maça': 55}

print(frutas.items())
print("\n")

# percorrendo chaves e valores
print("//percorrendo chabes e valores")
computador = {'CPU': 'Intel', 'RAM': '8gb', 'SSD': '250bg'}
for chave in computador.keys():
  print(f'Chave = {chave} e Valor = {computador[chave]}')
print("\n")

# adicionando itens
print("//adicionando itens")
dicionario = {'nome': 'Rick'}
print(dicionario)

dicionario['idade'] = 20
print(dicionario)
print("\n")

# atualizando itens
print("//atualizando itens")
dicionario = {'nome': 'Rick'}
print(dicionario)

dicionario.update({'nome':'Ricardo'})
print(dicionario)

dicionario.update({'idade':18})
dicionario.update(tamanho=1.60)

print(dicionario)
print("\n")

# excluindo valores
print("//excluindo valores")
pessoa = {'nome': 'Matheus', 'idade': 18, 'tamanho': 1.60}
print(pessoa)
del pessoa['tamanho']
print(pessoa)
print("\n")

# excluindo o valor e guardando o elemento excluído
print("//excluindo o valor e guardando o elemento excluído")
sacola = {'maça': 2, 'ovos': 6, 'farinha': 2}

ovos = sacola.pop('ovos')

print(ovos)
print(sacola)
print("\n")

# limpando o dicionario
print("//limpando o dicionario")
dicio = {'nome': 'F9', 'motor': 'v8', 'ano': 2019}
dicio.clear()

print(dicio)
dicio = {"operacao": "leitura", "dados": 250}
copia = dicio.copy()
print(copia)
print(dicio)
print("\n")

# agora adicionando um valor default
print("//agora adicionando um valor default")
dicio = {'coleta': 'leitura', 'status': 200}

set_data = dicio.setdefault('dados')
set_teste = dicio.setdefault('teste', 1)

print(set_data)
print(set_teste)
print(dicio)
print("\n")

# criando dicionario a partir de uma lista de valores
print("//criando dicionario a partir de uma lista de valores")
chaves = ['chave1', 'chave2', 'chave3']
valor = 0

dicio = dict.fromkeys(chaves , valor)

print(dicio)
print("\n")

# desempacotamento
print("//desempacotamento")
def funcao(argumento):
    print(argumento)


dicionario = {'argumento': 1}

funcao(dicionario)
funcao(**dicionario)
print("\n")

# Juntando dicionarios
print("//Juntando dicionarios")
regulagem = {'max': 10, 'meio': 5, 'min': 0}
extra = {'passo': 2}

juncao_dicio = {**regulagem, **extra}
print(juncao_dicio)
print("\n")