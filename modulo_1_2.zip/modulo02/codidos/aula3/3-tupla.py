# # tupla com parênteses / declaração implícita
# print("tupla com parênteses / declaração implícita")
# tupla_numeros = (10, 20, 30)
# print(tupla_numeros)
# print("\n")
 
# #tupla sem parênteses / declaração implícita
# print("tupla sem parênteses / declaração implícita")
# tupla_nova = 10, 20, 30
# print(tupla_nova)
# print("\n")

# # declaração explícita
# print("declaração explícita");
# nova_tupla = tuple('Teste')
# print(nova_tupla)
# tupla_vazia = tuple()
# print(tupla_vazia)
# print("\n")

# # nomear elementos da tupla
# print("nomear elementos da tupla")
# from collections import namedtuple
# Estados = namedtuple('Estados', ['sigla', 'nome'])
# estado_sp = Estados('SP', 'São Paulo')
# print(estado_sp)

# print(estado_sp.sigla)
# print(estado_sp.nome)
# print("\n")

# # existe determinado elemento na tupla
# print("existe determinado elemento na tupla")
# elementos_tupla = ('São Paulo', 'Belo Horizonte', 'Fortaleza')
# print('Belo Horizonte' in elementos_tupla)
# print("\n")

# # o elemento não existe na tupla
# print("o elemento não existe na tupla")
# elemento_tupla = ('São Paulo', 'Belo Horizonte', 'Fortaleza')
# print('Rio de Janeiro' in elemento_tupla)
# print("\n")

# # contar elementos
# print("contar elementos")
# tupla_nomes = ('Maria', 'Paulo', 'Maria', 'João', 'Sérgio')
# print (tupla_nomes.count('Maria'))

# print (tupla_nomes.count('Sérgio'))

# print (tupla_nomes.count('Pedro'))
# print("\n")

# # diferença tupla e lista
# print("diferença tupla e lista" )
# lista_nomes = ['Maria', 'João', 'Paulo']
# print (lista_nomes)
# print(type(lista_nomes))

# tupla_nomes = ('Maria', 'João', 'Paulo')
# print (tupla_nomes)
# print(type(tupla_nomes))
# print("\n")

# # preserva o id
# print("preserva o id" )
# tupla_coordenadas = (48.8032 ,  2.3488)
# print(tupla_coordenadas)
# print(id(tupla_coordenadas))

# tupla_coordenadas += (12345,)
# print(tupla_coordenadas)
# print(id(tupla_coordenadas))
# print("\n")

# acessar pelo id
print("acessar pelo id") 
# posicao 0  1  2  3  4  5  6  7  8  9 
valor = ( 1, 3, 7, 8, 7, 5, 4, 6, 8, 5 )
x = valor.index(8)
print(x) 

y = valor[0]
print(y)
print("\n")