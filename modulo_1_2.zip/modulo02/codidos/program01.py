def  write_name(name):
  print(name)

name = input('Digeite o nome: ')
write_name(name)