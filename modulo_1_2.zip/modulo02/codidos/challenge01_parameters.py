# Function for calculating hours worked

def CalculeteOvertime(qtde_extra_hour, hourValue):
  return (hourValue * 1.5)  * qtde_extra_hour ;

def CalculateHours(amountHours, hourValue):  
  amountHours =float(amountHours);
  hourValue =float(hourValue);

  if amountHours > 40:   
    qtde_extra_hour = amountHours - 40;
    print("Quantidade de hora extra: ", str(qtde_extra_hour))
    overtimeValue = CalculeteOvertime(qtde_extra_hour, hourValue);
    print("Valor hora extra: ", str(overtimeValue))

    wage = 40 * hourValue + overtimeValue;
  else:
    wage = amountHours * hourValue;

  return wage;

amountHours = input("Informe a quantidade de horas: ") ;
hourValue = input("Informe o valor da hora trabalhada: ") ;

payment = CalculateHours(amountHours, hourValue);
print("Salário semanal: ", str(payment));
