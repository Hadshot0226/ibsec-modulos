<html>
	<img src="https://app.ibsec.com.br/wp-content/themes/ibsec-2022/images/logo.webp" />
	<strong>Exercícios de IBSEC</strong>
</html>
