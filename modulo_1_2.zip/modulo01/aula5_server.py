import socket

c = socket.socket()

c.bind(('0.0.0.0', 8081))
c.listen(50)
print("Server started... waiting for connection")
c, addr = c.accept()
print("Recebido conexão do ip: ", addr)