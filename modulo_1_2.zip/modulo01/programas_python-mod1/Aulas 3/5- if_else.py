

estado = "SP"

if estado == "SP":
    print("Sao Paulo")
else:
    print("Outro Estado")