
#abrindo arquivo para gravar
arquivo = open("meu_arquivo.txt","w")
L = ["Gravando \n","Informacao \n","Pulando Linhas \n"] 
  
# \n Serve para pular as linhas
arquivo.write("Hello World\n")
arquivo.writelines(L)
arquivo.close() #fechando o arquivo
  
  
#lendo arquivo
arquivo = open("meu_arquivo.txt","r+") 
  
print("Informacoes do arquivo: \n")
print(arquivo.read())
#trazer todos registros em uma unica linha
print(arquivo.readlines())
