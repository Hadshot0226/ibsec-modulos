
# looping for
for contador in range(11):
    print(contador)
    
    

# looping while
contador = 0
while contador <= 10:
    print(contador)
    # soma um no valor do contador
    contador += 1
    

    