

valor1 = int(input("digite o primeiro numero: "))
valor2 = int(input("digite o segundo numero: "))

resultado = valor1 + valor2
print("Resultado :" + %s resultado)

#ou usar a forma abaixo, isto e um comentario

print("Resultado :" + str(resultado)) 


