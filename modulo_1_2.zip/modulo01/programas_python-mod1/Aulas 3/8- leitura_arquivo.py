file = open("lista.txt")

for linha in file.readlines():
    print(linha)
   
   



