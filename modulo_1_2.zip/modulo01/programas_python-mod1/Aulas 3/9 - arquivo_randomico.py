import random

lista=open("lista.txt").read().splitlines()
print(lista)
fruta = random.choice(lista)
informacao=fruta
print(fruta)