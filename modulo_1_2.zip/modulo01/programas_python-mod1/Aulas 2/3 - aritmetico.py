
numero1 = 10
numero2 = 5

resultado = numero1 / numero2

# resultado completo da divisao
print(resultado)

# resultado parte inteira da divisao
resultado = numero1 // numero2
print(resultado)

# resultado resto da divisao
resultado = numero1 % numero2
print(resultado)
