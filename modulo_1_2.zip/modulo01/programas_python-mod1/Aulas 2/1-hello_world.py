print("Hello World!!!)

texto = "Hello"
texto_2 = "World"

# print usando concatenacao
print("Mensagem: " +  texto + ' ' + texto_2)