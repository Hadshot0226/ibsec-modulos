nome = input('Digite seu nome: ')
print(nome)