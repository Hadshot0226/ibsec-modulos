#client
import socket
import time

# IP e porta destino
ip="192.168.15.6"
port=8081
c = socket.socket()
print("conectando no servidor")
#abrindo conexao
c.connect((ip,port))
#recebendo resposta
resposta = c.recv(2048).decode()
print(resposta)
c.close()