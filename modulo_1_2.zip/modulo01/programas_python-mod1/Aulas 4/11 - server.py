#server
import socket

c = socket.socket()
#escutar na porta 8081
c.bind(('0.0.0.0',8081))
c.listen(50)
print("Servidor iniciado aguardando conexao")
c, addr = c.accept()
print('[+] Recebeu conexao de:', addr)
