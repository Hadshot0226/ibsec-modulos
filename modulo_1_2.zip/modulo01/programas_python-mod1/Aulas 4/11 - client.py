#client
import socket

ip="192.168.15.6"
port=8081
c = socket.socket()
print("conectando no servidor")
#conectar no IP e porta destino
c.connect((ip,port))
c.close()