file = open("lista.txt")

for linha in file.readlines():
    print(linha)
    
    if "uva" in linha:
        print("[+] Uva encontrada na lista")
        break
    else:
        print("[-] buscando \n")
   



