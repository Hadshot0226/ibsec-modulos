fruits = ["apple", "banana", "orange" ]

for frut in fruits:
  print(frut)

for counter in range(10):
  print(counter)  

while counter > 0:
  counter -= 1
  print(counter)