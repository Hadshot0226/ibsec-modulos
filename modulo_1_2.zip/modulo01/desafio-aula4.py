# O programa deve ler uma lista de frutas, e exiba uma mensagem especifica quando encontrar 
# a fruta "uva"

file_fruits = open("fruits.txt")

for fruit in file_fruits:
  if "uva" in fruit:
    #print("Essa fruta ", fruit, " é muita boa")
    str ="Essa fruta {0} é muita boa"
    print(str.format(fruit))
  else:
    print(fruit)