numero1 = 10
numero2 = 5

# Divisão
resultado = numero1 / numero2
print(resultado)

# Inteiro da divisão
resultado = numero1  //  numero2
print(resultado)

# Resto
resultado = numero1  % numero2
print("Resto da disvisão: " + str(resultado))
"""
nome = input("Digite o seu nome: ")
print(nome)
"""