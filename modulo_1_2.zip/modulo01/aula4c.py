# Open file to write
"""
file = open('arquivo.txt', "w")
linha = ["Gravando \n", 'informacao \n', "pulando linhas \n"]

file.write("Ola \n")
file. writelines(linha)
file.close()
"""
"""
#Read file
file = open("arquivo.txt")
print("Lendo arquivo...")
#print(file.read())
print(file.readlines())
"""

file = open("lista.txt")

for line in file:
  print(line)