import random

list = open("lista.txt").read().splitlines()
print(list)
fruit = random.choice(list)
print(fruit)