from pydoc import cli
import socket

ip = '192.168.153.138'
porta = 8081

client = socket.socket()
print("Connecting with server")
client.connect((ip, porta))
x = input("Tecle qualquer tecla para sair")
client.close()