#dividendo = int(input("Digite o dividendo: "))
#divisor = int(input("Digite o divisor: "))

a = int(input("Digite o valor de a: "))
b = int(input("Digite o valro de b: "))
resultado = a + b

#print("Resultado da soma: ", str(resultado))
print("Resultado da soma:  ", resultado)
